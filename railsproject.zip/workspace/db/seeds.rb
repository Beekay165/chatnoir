Product.delete_all
Product.create! id: 1, name: "Posters", price: 5.49, active: true
Product.create! id: 2, name: "Illustrations", price: 5.29, active: true
Product.create! id: 3, name: "Woodblock Prints", price: 6.99, active: true

OrderStatus.delete_all
OrderStatus.create! id: 1, name: "In Progress"
OrderStatus.create! id: 2, name: "Placed"
OrderStatus.create! id: 3, name: "Shipped"
OrderStatus.create! id: 4, name: "Cancelled"